<?php
$server = "localhost";
$username = "root";
$passwords = "";
$db_name = "Assignment1 db";



###################################
		# MYSQL CONNECTION
###################################

$db_connection = mysqli_connect($server,$username,$passwords,$db_name);
if(!$db_connection){
	die ("Could not connect to database ".mysqli_error());
}


// function email_exist($email){

// $query = mysql_query("SELECT * FROM Users WHERE email=$email", $db_connection);

//   if (mysql_num_rows($query) != 0)
//   {
//       echo "Email already exists";
//   }

//   return $query;
// }