<?php

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST,GET,OPTIONS');
header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept');
error_reporting(E_ALL);
ini_set('display_errors',1);

include("connect_php/connect.php");
// $data = json_decode(file_get_contents("php://input"));

$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$email = $_POST['email'];
$password = $_POST['password'];
$id = "";

$dataArray = array();

$testSwitch = $_POST["submit"];

switch ($testSwitch) 
{
	case 'register':

		$prepare_proc = $db_connection->prepare('CALL register_user(?,?,?,?)');

		if(!$prepare_proc)
		{
			echo "bad prepared statement";
		}

		$prepare_proc->bind_param('ssss',$firstname,$lastname,$email,$password);

		$prepare_proc->execute();

		$prepare_proc->bind_result($id,$firstname,$lastname,$email,$password);

		while ($prepare_proc->fetch())
		{
			array_push($dataArray, array('userID' => $id,
											'firstname' => $firstname,
											'lastname' => $lastname,
											'email' => $email,
											'password' => $password));
		}

	break;
	
}


		echo json_encode($dataArray);
		$db_connection->close();
?>