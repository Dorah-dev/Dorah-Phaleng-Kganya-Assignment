
//###############################################################################
//##### Creating our factory service by calling our angular module variable.#####
//##### factory Receives 2 parameters which are factory name and  ##########
//##### function that receives 2 parameters of $http and $q->promise #######
//###############################################################################

Assignment1 App.factory("registerFactory",function($http,$q){
	return {
		//############################
		//### Creating a new function that receives a paratemer of user details
	 signup:function(userDetails){
	 		//variable from API which define our switch case
			var action = 'register';

			//url,method,data,headers ($.param)are predefined functions of http in angular
		return $http({

					url : "http://localhost/Assignment1 App/www/php/reg_users.php",
					method : "POST",
					data : $.param({ 'submit' : action,
									'firstname' : userDetails.firstname, //###############################
									'lastname' : userDetails.lastname,  //### Variables from controller ##
									'email' : userDetails.email,		  //################################
									'password' : userDetails.password}),
					headers: {'Content-Type': 'application/x-www-form-urlencoded'}
					
				}).success(function(response){
						console.log("successful");
					}).error(function(response){
						console.log("Problem occured");
					})
		}
	};
});

Assignment1 App.factory("loginFactory", function()
{

});






