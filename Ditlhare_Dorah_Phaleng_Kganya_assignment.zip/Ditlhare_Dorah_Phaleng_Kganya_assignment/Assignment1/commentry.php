<!DOCTYPE html>
<html  ng-app = "app" >
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no, width=device-width">
  <title></title>
   <script src="http://code.jquery.com/jquery-2.0.3.min.js"></script>
  <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/angularjs/1.0.7/angular.min.js"></script>
<!--   // <script type="text/javascript" src="./js/js_js/comment.js"></script> -->
  <link href="lib/ionic/css/ionic.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
  <link href="css/card.css" rel="stylesheet">
 

   <script type="text/javascript" src="js/app.js"></script>
   <script type="text/javascript" src="js/Controller.js"></script>
 <script type="text/javascript" src="js/Factory.js"></script>
 <script type="text/javascript" src="./js/js_js/validation.js"></script>
 
</head>



<body ng-controller="feedbackCtrl">
<div class="bar bar-header">
<a href="home.php"><button class="button button-icon ion-ios-arrow-back"></button></a>
<div class="h1 title">Post Feedback</div>

</div>

  <ion-pane>
  
<form action = "" method="post">
<ion-view view-title="Feedback" name="login-view" class="padding">
<ion-content>
<br>
<br>
<h4>Drop us a line</h4>
<h5>What do you like about our service? <br>What service do you want in future? <br>Contact us and let us know!</h5>
    <div class="list list-inset">
    <br>   
          <p align ="center" id="confirmMessage" class="confirmMessage"></p>
         <h6> * Your Email : </h6>
         <label class="item item-input">
         <input type="text" name = "userEmail" ng-model = "userEmail" onblur="validateEmail(this);" required>
         </label>
         
         <h6> * Subject : </h6>
         <label class="item item-input">
         <input type="text" name = "subject" ng-model = "subject">
         </label>
    </div>
    
    <h6> * Your Message : </h6>
     <label class="item item-input">
        
              <textarea placeholder="Post Feedback . . . ." cols="50" rows="10" maxlength="300" ng-model = "feedback" name="comment"></textarea>
        </label>
        <button class="button button-block button-calm" ng-click="postFeedback()" name="postFeedback">Send Email</button>

    </div>
 </div>

    
  
    
</ion-content>
</ion-view>
</form>
  </ion-pane>
 
</body>
</html>